package com.CS320.project1;

import java.util.Date;

public class Appointment {
/*
 * ===================================================
 * 					ATTRIBUTES
 * ===================================================
*/
	private static final int ID_LENGTH = 10;
	private static final int DESCRIPTION_LENGTH = 50;
	private static final String INITIALIZE = null;
		
	private String id;
	private Date date;
	private String description;

/*
 * ===================================================
 * 					CONSTRUCTORS
 * ===================================================
*/
	Appointment() {
		id = description = INITIALIZE;
		date = null;
	}
	
	Appointment(String id, Date date, String description) {
		setId(id);
		setDate(date); 
		setDescription(description);
	}

/*
 * ===================================================
 * 					MUTATORS
 * ===================================================
*/
	
	private void setId (String id) {
		if ((id == null) || (id.length() > ID_LENGTH || (id == ""))) {
			throw new IllegalArgumentException("ID cannot be empty and" +
				"cannot exceed ID_LENGTH characters");
		}
		else {
			this.id = id;
		}
	}
	
	protected void setDate (Date date) {
		if (date == null) {
			throw new IllegalArgumentException("Date cannot be empty");
		}
		else if (date.before(new Date())) {
			throw new IllegalArgumentException("Date cannot be made in the past");
		}
		else {
			this.date = date;
		}
	}
	
	protected void setDescription (String description) {
		if ((description == null) || (description.length() > DESCRIPTION_LENGTH || (description == ""))) {
			throw new IllegalArgumentException("Description cannot be empty and" +
					"cannot exceed " + DESCRIPTION_LENGTH + "characters");
		}
		else {
			this.description = description;
		}
	}

/*
 * ===================================================
 * 					ACCESSORS
 * ===================================================
*/
	protected String getId() {return id;}
	protected Date getDate() {return date;}
	protected String getDescription() {return description;}
	
}