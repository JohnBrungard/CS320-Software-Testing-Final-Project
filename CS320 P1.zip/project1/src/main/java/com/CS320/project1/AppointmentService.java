package com.CS320.project1;

import java.util.ArrayList;
import java.util.UUID;
import java.util.Date;

public class AppointmentService {
	protected static ArrayList<Appointment> apptList = new ArrayList();

	protected static String createId() {
		String uniqueId = UUID.randomUUID().toString().substring(0, 10);

		if (search(uniqueId) != null) {
			throw new IllegalArgumentException("Unique ID already exists");
		}
		return uniqueId;
	}

/*
 * =================================================== 
 * 					ArrayList Operations
 * ===================================================
 */
	public static void addAppt(Date date, String description) {
		Appointment appt = new Appointment(createId(), date, description);

		apptList.add(appt);
		
		for (int i = 0; i < apptList.size(); i++) {
			if (appt.getId() == apptList.get(i).getId()) {
				System.out.println("Add successful");
				
				break;
			}
		}
	}

	protected static Appointment search(String id) {
		for (int i = 0; i < apptList.size(); ++i) {
			if (id.equals(apptList.get(i).getId())) {
				return apptList.get(i);
			}
		}
		return null;
	}

	public static void remove(String id) {
		if (search(id) != null) {
			apptList.remove(search(id));
			
			for (int i = 0; i < apptList.size(); i++) {
				if (id == apptList.get(i).getId()) {
					System.out.println("Remove unsuccessful");
					
					break;
				}
				else if (i == apptList.size() - 1) {
					System.out.println("Removal successful");
				}
			}
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}
}
