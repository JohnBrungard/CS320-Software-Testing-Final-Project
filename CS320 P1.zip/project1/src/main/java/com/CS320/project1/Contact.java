package com.CS320.project1;

public class Contact {
/*
 * ===================================================
 * 					ATTRIBUTES
 * ===================================================
*/
	private static final int ID_LENGTH = 10;
	private static final int FIRST_NAME_LENGTH = 10;
	private static final int LAST_NAME_LENGTH = 10;
	private static final int PHONE_LENGTH = 10;
	private static final int ADDRESS_LENGTH = 30;
	private static final String INITIALIZE = null;
		
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

/*
 * ===================================================
 * 					CONSTRUCTORS
 * ===================================================
*/
	Contact() {
		id = firstName = lastName = phone = address = INITIALIZE;
	}
	
	Contact(String id, String firstName, String lastName, String phone, String address) {
		setId(id);
		setFirstName(firstName); 
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}

/*
 * ===================================================
 * 					MUTATORS
 * ===================================================
*/
	
	private void setId (String id) {
		if ((id == null) || (id.length() > ID_LENGTH || (id == ""))) {
			throw new IllegalArgumentException("ID cannot be empty and" +
				"cannot exceed ID_LENGTH characters");
		}
		else {
			this.id = id;
		}
	}
	
	protected void setFirstName (String firstName) {
		if ((firstName == null) || (firstName.length() > FIRST_NAME_LENGTH || (firstName == ""))) {
			throw new IllegalArgumentException("First Name cannot be empty and" +
					"cannot exceed " + FIRST_NAME_LENGTH + "characters");
		}
		else {
			this.firstName = firstName;
		}
	}
	
	protected void setLastName (String lastName) {
		if ((lastName == null) || (lastName.length() > LAST_NAME_LENGTH || (lastName == ""))) {
			throw new IllegalArgumentException("Last Name cannot be empty and" +
					"cannot exceed " + LAST_NAME_LENGTH + "characters");
		}
		else {
			this.lastName = lastName;
		}
	}
	
	protected void setPhone (String phone) {
		if ((phone == null) || (phone.length() != PHONE_LENGTH)) {
			throw new IllegalArgumentException("Phone # cannot be empty and" +
					"must equal " + PHONE_LENGTH + "characters");
		}
		else if (!phone.matches("[0-9]+")) {
			throw new IllegalArgumentException("Phone # must only contain digits.");
		}
		else {
			this.phone = phone;
		}
	}
	
	protected void setAddress (String address) {
		if ((address == null) || (address.length() > ADDRESS_LENGTH || (address == ""))) {
			throw new IllegalArgumentException("Address cannot be empty and" +
					"cannot exceed " + ADDRESS_LENGTH + "characters");
		}
		else {
			this.address = address;
		}
	}

/*
 * ===================================================
 * 					ACCESSORS
 * ===================================================
*/
	protected String getId() {return id;}
	protected String getFirstName() {return firstName;}
	protected String getLastName() {return lastName;}
	protected String getPhone() {return phone;}
	protected String getAddress() {return address;}
	
}