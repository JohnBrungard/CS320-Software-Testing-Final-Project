package com.CS320.project1;

import java.util.ArrayList;
import java.util.UUID;

public class ContactService {
	protected static ArrayList<Contact> contactList = new ArrayList();

	protected static String createId() {
		String uniqueId = UUID.randomUUID().toString().substring(0, 10);

		if (search(uniqueId) != null) {
			throw new IllegalArgumentException("Unique ID already exists");
		}
		return uniqueId;
	}

/*
 * =================================================== 
 * 					UPDATE INFO
 * ===================================================
*/
	public static void updateFirstName(String id, String firstName) {
		if (search(id) != null) {
			search(id).setFirstName(firstName);
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

	public static void updateLastName(String id, String lastName) {
		if (search(id) != null) {
			search(id).setLastName(lastName);
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

	public static void updatePhone(String id, String phone) {
		if (search(id) != null) {
			search(id).setPhone(phone);
		} else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

	public static void updateAddress(String id, String address) {
		if (search(id) != null) {
			search(id).setAddress(address);
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

/*
 * =================================================== 
 * 					ArrayList Operations
 * ===================================================
*/
	public static void addContact(String firstName, String lastName, String phone, String address) {
		Contact contact = new Contact(createId(), firstName, lastName, phone, address);
		
		contactList.add(contact);
		
		for (int i = 0; i < contactList.size(); i++) {
			if (contact.getId() == contactList.get(i).getId()) {
				System.out.println("Add successful");
				
				break;
			}				
		}
	}
	
	protected static Contact search(String id) {
		for (int i = 0; i < contactList.size(); ++i) {
			if (id.equals(contactList.get(i).getId())) {
				return contactList.get(i);
			}
		}
		return null;
	}

	public static void remove(String id) {
		if (search(id) != null) {
			contactList.remove(search(id));
			
			for (int i = 0; i < contactList.size(); i++) {
				if (id == contactList.get(i).getId()) {
					System.out.println("Remove unsuccessful");
					
					break;
				}
				else if (i == contactList.size() - 1) {
					System.out.println("Removal successful");
				}
			}
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}
}
