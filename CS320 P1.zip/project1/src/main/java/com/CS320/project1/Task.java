package com.CS320.project1;

public class Task {
/*
 * ===================================================
 * 					ATTRIBUTES
 * ===================================================
*/
	private static final int ID_LENGTH = 10;
	private static final int NAME_LENGTH = 20;
	private static final int DESCRIPTION_LENGTH = 50;
	private static final String INITIALIZE = null;
		
	private String id;
	private String name;
	private String description;

/*
 * ===================================================
 * 					CONSTRUCTORS
 * ===================================================
*/
	Task() {
		id = name = description = INITIALIZE;
	}
	
	Task(String id, String name, String description) {
		setId(id);
		setName(name); 
		setDescription(description);
	}

/*
 * ===================================================
 * 					MUTATORS
 * ===================================================
*/
	
	private void setId (String id) {
		if ((id == null) || (id.length() > ID_LENGTH || (id == ""))) {
			throw new IllegalArgumentException("ID cannot be empty and" +
				"cannot exceed ID_LENGTH characters");
		}
		else {
			this.id = id;
		}
	}
	
	protected void setName (String name) {
		if ((name == null) || (name.length() > NAME_LENGTH || (name == ""))) {
			throw new IllegalArgumentException("Name cannot be empty and" +
					"cannot exceed " + NAME_LENGTH + "characters");
		}
		else {
			this.name = name;
		}
	}
	
	protected void setDescription (String description) {
		if ((description == null) || (description.length() > DESCRIPTION_LENGTH || (description == ""))) {
			throw new IllegalArgumentException("Description cannot be empty and" +
					"cannot exceed " + DESCRIPTION_LENGTH + "characters");
		}
		else {
			this.description = description;
		}
	}

/*
 * ===================================================
 * 					ACCESSORS
 * ===================================================
*/
	protected String getId() {return id;}
	protected String getName() {return name;}
	protected String getDescription() {return description;}
	
}