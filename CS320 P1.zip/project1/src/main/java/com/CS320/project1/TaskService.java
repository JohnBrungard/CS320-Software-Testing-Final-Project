package com.CS320.project1;

import java.util.ArrayList;
import java.util.UUID;

public class TaskService {
	protected static ArrayList<Task> taskList = new ArrayList();

	protected static String createId() {
		String uniqueId = UUID.randomUUID().toString().substring(0, 10);

		if (search(uniqueId) != null) {
			throw new IllegalArgumentException("Unique ID already exists");
		}
		return uniqueId;
	}

/*
 * =================================================== 
 * 					UPDATE INFO
 * ===================================================
*/
	public static void updateName(String id, String name) {
		if (search(id) != null) {
			search(id).setName(name);
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

	public static void updateDescription(String id, String description) {
		if (search(id) != null) {
			search(id).setDescription(description);
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}

/*
 * =================================================== 
 * 					ArrayList Operations
 * ===================================================
 */
	public static void addTask(String name, String description) {
		Task task = new Task(createId(), name, description);

		taskList.add(task);
		
		for (int i = 0; i < taskList.size(); i++) {
			if (task.getId() == taskList.get(i).getId()) {
				System.out.println("Add successful");
				
				break;
			}
		}
	}

	protected static Task search(String id) {
		for (int i = 0; i < taskList.size(); ++i) {
			if (id.equals(taskList.get(i).getId())) {
				return taskList.get(i);
			}
		}
		return null;
	}

	public static void remove(String id) {
		if (search(id) != null) {
			taskList.remove(search(id));
			
			for (int i = 0; i < taskList.size(); i++) {
				if (id == taskList.get(i).getId()) {
					System.out.println("Remove unsuccessful");
					
					break;
				}
				else if (i == taskList.size() - 1) {
					System.out.println("Removal successful");
				}
			}
		} 
		else {
			throw new IllegalArgumentException("ID not found within the system");
		}
	}
}
