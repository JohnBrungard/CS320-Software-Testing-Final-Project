package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import java.util.Date;
import java.util.concurrent.TimeUnit;

@TestInstance(Lifecycle.PER_CLASS)
public class AppointmentServiceTest {
	protected String DESCRIPTION, GOOD_DESCRIPTION;
	protected String BAD_ID, BAD_DESCRIPTION;
	protected String UNIQUE_ID; 
	protected int ID_COMPARISONS;
	protected Date GOOD_DATE, DATE, BAD_DATE;
	
	@BeforeAll
	void setup() { 
		DATE = new Date(TimeUnit.SECONDS.toMillis(1670379000)); // DEC 18 2022
		DESCRIPTION = "b";
			
		GOOD_DATE = new Date(TimeUnit.SECONDS.toMillis(1892000000)); // JAN 1 2030
		GOOD_DESCRIPTION = "Update user info daily on Sunday at just midnight.";		
		
		BAD_ID = "abc!@#ghi47";
		BAD_DATE = new Date(TimeUnit.SECONDS.toMillis(1667835000)); // NOV 18 2022
		BAD_DESCRIPTION = "";
		
		ID_COMPARISONS = 1000;
	}
	
	@BeforeEach 
	void createList() {
		AppointmentService.addAppt(GOOD_DATE, GOOD_DESCRIPTION);
		AppointmentService.addAppt(DATE, DESCRIPTION);
	}
	
	@AfterEach
	void popList() {
		AppointmentService.apptList.clear();
	}
	
	@DisplayName("Good Add Task")
	@Test
	void testOne() {
		assertTrue(AppointmentService.apptList.get(0).getId().equals(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId()));
		assertTrue(AppointmentService.apptList.get(0).getDate().equals(GOOD_DATE));
		assertTrue(AppointmentService.apptList.get(0).getDescription().equals(GOOD_DESCRIPTION));
		
		assertTrue(AppointmentService.apptList.get(1).getId().equals(AppointmentService.search(AppointmentService.apptList.get(1).getId()).getId()));
		assertTrue(AppointmentService.apptList.get(1).getDate().equals(DATE));
		assertTrue(AppointmentService.apptList.get(1).getDescription().equals(DESCRIPTION));
	}
	
	@DisplayName("Bad Add Task")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			AppointmentService.addAppt(BAD_DATE, BAD_DESCRIPTION);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			AppointmentService.addAppt(GOOD_DATE, BAD_DESCRIPTION);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			AppointmentService.addAppt(BAD_DATE, GOOD_DESCRIPTION);
		});
	}
	
	@DisplayName("Good Search")
	@Test
	void testThree() {
		assertEquals(AppointmentService.apptList.get(0).getId(), AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId());
		assertEquals(AppointmentService.apptList.get(0).getDate(), AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDate());
		assertEquals(AppointmentService.apptList.get(0).getDescription(), AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDescription());
		
		assertEquals(AppointmentService.apptList.get(1).getId(), AppointmentService.search(AppointmentService.apptList.get(1).getId()).getId());
		assertEquals(AppointmentService.apptList.get(1).getDate(), AppointmentService.search(AppointmentService.apptList.get(1).getId()).getDate());
		assertEquals(AppointmentService.apptList.get(1).getDescription(), AppointmentService.search(AppointmentService.apptList.get(1).getId()).getDescription());		
	}
	
	@DisplayName("Bad Search")
	@Test
	void testFour() {
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId().equals(BAD_ID));
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDate().equals(BAD_DATE));
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDescription().equals(BAD_DESCRIPTION));
		
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId().equals(BAD_ID));
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDate().equals(BAD_DATE));
		assertFalse(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDescription().equals(BAD_DESCRIPTION));		
	}
	
	@DisplayName("Remove")
	@Test
	void testFive() {
		UNIQUE_ID = AppointmentService.apptList.get(0).getId();
		AppointmentService.remove(AppointmentService.apptList.get(0).getId());
				
		assertTrue(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId().equals(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getId()));
		assertTrue(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDate().equals(DATE));
		assertTrue(AppointmentService.search(AppointmentService.apptList.get(0).getId()).getDescription().equals(DESCRIPTION));
		
		assertNull(AppointmentService.search(UNIQUE_ID));
	}

	@DisplayName("Unique ID")
	@Test
	void testSix() {
		for (int i = 0; i < ID_COMPARISONS; i++) {
			assertFalse(AppointmentService.createId().equals(AppointmentService.apptList.get(0).getId()));
			assertFalse(AppointmentService.createId().equals(AppointmentService.apptList.get(1).getId()));
		}		
	}
}



