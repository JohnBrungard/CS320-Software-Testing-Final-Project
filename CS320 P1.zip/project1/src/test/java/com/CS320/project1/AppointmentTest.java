package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import java.util.Date;

@TestInstance(Lifecycle.PER_CLASS)
public class AppointmentTest {
	protected String GOOD_ID, GOOD_DESCRIPTION;
	protected String NULL_ID, NULL_DESCRIPTION;
	protected String LONG_ID, LONG_DESCRIPTION;
	protected Appointment GOOD_APPT, BAD_APPT, NULL_APPT, EMPTY_APPT;
	protected Date GOOD_DATE, NULL_DATE, BAD_DATE;
	
	@BeforeAll
	void setup() {
		GOOD_ID = "\123abc!@#";
		GOOD_DATE = new Date(); // CURRENT TIME
		GOOD_DESCRIPTION = "Automatically assigns weekly appointments for you.";
		
		NULL_ID  = NULL_DESCRIPTION = null;
		NULL_DATE = null;
		
		LONG_ID = "z123zuv!@#a123zvu!@#";
		LONG_DESCRIPTION = "The @ppointment object shall have a required description String field that "
				+ "cannot be longer than 50 characters.";
		BAD_DATE = new Date(0); // JAN 1 1970
		
		GOOD_APPT = new Appointment(GOOD_ID, GOOD_DATE, GOOD_DESCRIPTION);
	}
	
	@DisplayName("Good Test")
	@Test
	void testOne() {	
		assertTrue(GOOD_APPT.getId().equals(GOOD_ID));
		assertTrue(GOOD_APPT.getDate().equals(GOOD_DATE));
		assertTrue(GOOD_APPT.getDescription().equals(GOOD_DESCRIPTION));
	}
	
	@DisplayName("Null Test")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment NULL_APPT = new Appointment(NULL_ID, GOOD_DATE, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment NULL_APPT = new Appointment(GOOD_ID, NULL_DATE, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment NULL_APPT = new Appointment(GOOD_ID, GOOD_DATE, NULL_DESCRIPTION);						
		});
		
	}
	
	@DisplayName("Empty Test")
	@Test
	void testThree() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment EMPTY_APPOINTMENT = new Appointment("", GOOD_DATE, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment EMPTY_APPOINTMENT = new Appointment(GOOD_ID, GOOD_DATE, "");						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment EMPTY_APPOINTMENT = new Appointment("", GOOD_DATE, "");						
		});
	}
	
	@DisplayName("Bad Test")
	@Test
	void testFour() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_APPT.setDate(BAD_DATE);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_APPT.setDescription(LONG_DESCRIPTION);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Appointment BAD_APPOINTMENT = new Appointment(LONG_ID, BAD_DATE, LONG_DESCRIPTION);
		});
	}
}
