package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class ContactServiceTest {
	protected String F_NAME, L_NAME, PHONE, ADDRESS;
	protected String GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS;
	protected String BAD_ID, BAD_F_NAME, BAD_L_NAME, BAD_PHONE, BAD_ADDRESS;
	protected String UNIQUE_ID;
	protected int ID_COMPARISONS;
	
	@BeforeAll
	void setup() {
		F_NAME = "a";
		L_NAME = "b";
		PHONE = "0123456789";
		ADDRESS = "c";
			
		GOOD_F_NAME = "Jazmyn";
		GOOD_L_NAME = "Clements";
		GOOD_PHONE = "1357902468";
		GOOD_ADDRESS = "321 LO RD, city, CA, 12345";		
		
		BAD_ID = "abcdefghijk";
		BAD_F_NAME = "";
		BAD_L_NAME = "wxyz0123456";
		BAD_PHONE = "789!@#$%^&";
		BAD_ADDRESS = "0123456789012345678901234567890123456789";
		
		ID_COMPARISONS = 1000;
	}
	
	@BeforeEach 
	void createList() {
		ContactService.addContact(GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);
		ContactService.addContact(F_NAME, L_NAME, PHONE, ADDRESS);
	}
	
	@AfterEach
	void popList() {
		ContactService.contactList.clear();
	}
	
	@DisplayName("Good Add Contact")
	@Test
	void testOne() {
		assertTrue(ContactService.contactList.get(0).getFirstName().equals(GOOD_F_NAME));
		assertTrue(ContactService.contactList.get(0).getLastName().equals(GOOD_L_NAME));
		assertTrue(ContactService.contactList.get(0).getPhone().equals(GOOD_PHONE));
		assertTrue(ContactService.contactList.get(0).getAddress().equals(GOOD_ADDRESS));
		
		assertTrue(ContactService.contactList.get(1).getFirstName().equals(F_NAME));
		assertTrue(ContactService.contactList.get(1).getLastName().equals(L_NAME));
		assertTrue(ContactService.contactList.get(1).getPhone().equals(PHONE));
		assertTrue(ContactService.contactList.get(1).getAddress().equals(ADDRESS));
	}
	
	@DisplayName("Bad Add Contact")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.addContact(BAD_F_NAME, BAD_L_NAME, BAD_PHONE, BAD_ADDRESS);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.addContact(GOOD_F_NAME, BAD_L_NAME, BAD_PHONE, BAD_ADDRESS);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.addContact(BAD_F_NAME, GOOD_L_NAME, BAD_PHONE, BAD_ADDRESS);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.addContact(BAD_F_NAME, BAD_L_NAME, GOOD_PHONE, BAD_ADDRESS);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.addContact(BAD_F_NAME, BAD_L_NAME, BAD_PHONE, GOOD_ADDRESS);
		});
	}
	
	@DisplayName("Good Search")
	@Test
	void testThree() {
		assertEquals(ContactService.contactList.get(0).getId(), ContactService.search(ContactService.contactList.get(0).getId()).getId());
		assertEquals(ContactService.contactList.get(0).getFirstName(), ContactService.search(ContactService.contactList.get(0).getId()).getFirstName());
		assertEquals(ContactService.contactList.get(0).getLastName(), ContactService.search(ContactService.contactList.get(0).getId()).getLastName());
		assertEquals(ContactService.contactList.get(0).getPhone(), ContactService.search(ContactService.contactList.get(0).getId()).getPhone());
		assertEquals(ContactService.contactList.get(0).getAddress(), ContactService.search(ContactService.contactList.get(0).getId()).getAddress());
		
		assertEquals(ContactService.contactList.get(1).getId(), ContactService.search(ContactService.contactList.get(1).getId()).getId());
		assertEquals(ContactService.contactList.get(1).getFirstName(), ContactService.search(ContactService.contactList.get(1).getId()).getFirstName());
		assertEquals(ContactService.contactList.get(1).getLastName(), ContactService.search(ContactService.contactList.get(1).getId()).getLastName());
		assertEquals(ContactService.contactList.get(1).getPhone(), ContactService.search(ContactService.contactList.get(1).getId()).getPhone());
		assertEquals(ContactService.contactList.get(1).getAddress(), ContactService.search(ContactService.contactList.get(1).getId()).getAddress());
	}
	
	@DisplayName("Bad Search")
	@Test
	void testFour() {
		assertFalse(ContactService.search(ContactService.contactList.get(0).getId()).getId().equals(BAD_ID));
		assertFalse(ContactService.search(ContactService.contactList.get(0).getId()).getFirstName().equals(BAD_F_NAME));
		assertFalse(ContactService.search(ContactService.contactList.get(0).getId()).getLastName().equals(BAD_L_NAME));
		assertFalse(ContactService.search(ContactService.contactList.get(0).getId()).getPhone().equals(BAD_PHONE));
		assertFalse(ContactService.search(ContactService.contactList.get(0).getId()).getAddress().equals(BAD_ADDRESS));
		
		assertFalse(ContactService.search(ContactService.contactList.get(1).getId()).getId().equals(BAD_ID));
		assertFalse(ContactService.search(ContactService.contactList.get(1).getId()).getFirstName().equals(BAD_F_NAME));
		assertFalse(ContactService.search(ContactService.contactList.get(1).getId()).getLastName().equals(BAD_L_NAME));
		assertFalse(ContactService.search(ContactService.contactList.get(1).getId()).getPhone().equals(BAD_PHONE));
		assertFalse(ContactService.search(ContactService.contactList.get(1).getId()).getAddress().equals(BAD_ADDRESS));
	}
	
	@DisplayName("Remove")
	@Test
	void testFive() {
		UNIQUE_ID = ContactService.contactList.get(0).getId();
		ContactService.remove(ContactService.contactList.get(0).getId());
				
		assertTrue(ContactService.search(ContactService.contactList.get(0).getId()).getId().equals(ContactService.search(ContactService.contactList.get(0).getId()).getId()));
		assertTrue(ContactService.search(ContactService.contactList.get(0).getId()).getFirstName().equals(F_NAME));
		assertTrue(ContactService.search(ContactService.contactList.get(0).getId()).getLastName().equals(L_NAME));
		assertTrue(ContactService.search(ContactService.contactList.get(0).getId()).getPhone().equals(PHONE));
		assertTrue(ContactService.search(ContactService.contactList.get(0).getId()).getAddress().equals(ADDRESS));
		
		assertNull(ContactService.search(UNIQUE_ID));
	}
	
	@DisplayName("Update Info")
	@Test
	void testSix() {
		ContactService.updateFirstName(ContactService.contactList.get(0).getId(), "z");
		ContactService.updateLastName(ContactService.contactList.get(0).getId(), "y");
		ContactService.updatePhone(ContactService.contactList.get(0).getId(), "9876543210");
		ContactService.updateAddress(ContactService.contactList.get(0).getId(), "x");
		
		assertTrue(ContactService.contactList.get(0).getId().equals(ContactService.search(ContactService.contactList.get(0).getId()).getId()));
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("z"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("y"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("9876543210"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("x"));
		
		ContactService.updateFirstName(ContactService.contactList.get(1).getId(), "w");
		ContactService.updateLastName(ContactService.contactList.get(1).getId(), "v");
		ContactService.updatePhone(ContactService.contactList.get(1).getId(), "9753186420");
		ContactService.updateAddress(ContactService.contactList.get(1).getId(), "u");
		
		assertTrue(ContactService.contactList.get(1).getId().equals(ContactService.search(ContactService.contactList.get(1).getId()).getId()));
		assertTrue(ContactService.contactList.get(1).getFirstName().equals("w"));
		assertTrue(ContactService.contactList.get(1).getLastName().equals("v"));
		assertTrue(ContactService.contactList.get(1).getPhone().equals("9753186420"));
		assertTrue(ContactService.contactList.get(1).getAddress().equals("u"));
	}
	
	@DisplayName("Unique ID")
	@Test
	void testSeven() {
		for (int i = 0; i < ID_COMPARISONS; i++) {
			assertFalse(ContactService.createId().equals(ContactService.contactList.get(0).getId()));
			assertFalse(ContactService.createId().equals(ContactService.contactList.get(1).getId()));
		}		
	}
}