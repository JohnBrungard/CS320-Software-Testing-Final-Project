package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class ContactTest {
	protected String GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS;
	protected String NULL_ID, NULL_F_NAME, NULL_L_NAME, NULL_PHONE, NULL_ADDRESS;
	protected String LONG_ID, LONG_F_NAME, LONG_L_NAME, LONG_PHONE, LONG_ADDRESS;
	protected Contact GOOD_CONTACT, BAD_CONTACT, NULL_CONTACT, EMPTY_CONTACT;
	
	@BeforeAll
	void setup() {
		GOOD_ID = "a123abc!@#";
		GOOD_F_NAME = "John";
		GOOD_L_NAME = "Brungard";
		GOOD_PHONE = "0123456789";
		GOOD_ADDRESS = "123 HI DR, city, OR, 54872";
		
		NULL_ID = NULL_F_NAME = NULL_L_NAME = NULL_PHONE = NULL_ADDRESS = null;
		
		LONG_ID = "a123abc!@#a123abc!@#";
		LONG_F_NAME = "JohnJohnJohn";
		LONG_L_NAME = "BrungardBrungard";
		LONG_PHONE = "0";
		LONG_ADDRESS = "123 HI DR, city, OR, 54872 123 HI DR, city, OR, 54872";
		
		GOOD_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);
	}
	
	@DisplayName("Good Test")
	@Test
	void testOne() {	
		assertTrue(GOOD_CONTACT.getId().equals(GOOD_ID));
		assertTrue(GOOD_CONTACT.getFirstName().equals(GOOD_F_NAME));
		assertTrue(GOOD_CONTACT.getLastName().equals(GOOD_L_NAME));
		assertTrue(GOOD_CONTACT.getPhone().equals(GOOD_PHONE));
		assertTrue(GOOD_CONTACT.getAddress().equals(GOOD_ADDRESS));
	}
	
	@DisplayName("Null Test")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact NULL_CONTACT = new Contact(NULL_ID, GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact NULL_CONTACT = new Contact(GOOD_ID, NULL_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact NULL_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, NULL_L_NAME, GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact NULL_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, NULL_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact NULL_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, NULL_ADDRESS);						
		});
	}
	
	@DisplayName("Empty Test")
	@Test
	void testThree() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact EMPTY_CONTACT = new Contact("", GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact EMPTY_CONTACT = new Contact(GOOD_ID, "", GOOD_L_NAME, GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact EMPTY_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, "", GOOD_PHONE, GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact EMPTY_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, "", GOOD_ADDRESS);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact EMPTY_CONTACT = new Contact(GOOD_ID, GOOD_F_NAME, GOOD_L_NAME, GOOD_PHONE, "");						
		});
	}
	
	@DisplayName("Bad Test")
	@Test
	void testFour() {	
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_CONTACT.setFirstName(LONG_F_NAME);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_CONTACT.setLastName(LONG_L_NAME);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_CONTACT.setPhone(LONG_PHONE);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_CONTACT.setAddress(LONG_ADDRESS);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Contact BAD_CONTACT  = new Contact(LONG_ID, LONG_F_NAME, LONG_L_NAME, LONG_PHONE, LONG_ADDRESS);
		});		
	}
}
