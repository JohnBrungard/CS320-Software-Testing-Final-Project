package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TaskServiceTest {
	protected String NAME, DESCRIPTION;
	protected String GOOD_NAME, GOOD_DESCRIPTION;
	protected String BAD_ID, BAD_NAME, BAD_DESCRIPTION;
	protected String UNIQUE_ID; 
	protected int ID_COMPARISONS;
	
	@BeforeAll
	void setup() {
		NAME = "a";
		DESCRIPTION = "b";
			
		GOOD_NAME = "Jazmyn Clements";
		GOOD_DESCRIPTION = "Update user info daily on Sunday at just midnight.";		
		
		BAD_ID = "";
		BAD_NAME = "lmnopqrstuvwxyz0123456";
		BAD_DESCRIPTION = "012345678901234567890123456789012345678901234567a!/";
		
		ID_COMPARISONS = 1000;
	}
	
	@BeforeEach 
	void createList() {
		TaskService.addTask(GOOD_NAME, GOOD_DESCRIPTION);
		TaskService.addTask(NAME, DESCRIPTION);
	}
	
	@AfterEach
	void popList() {
		TaskService.taskList.clear();
	}
	
	@DisplayName("Good Add Task")
	@Test
	void testOne() {
		assertTrue(TaskService.taskList.get(0).getId().equals(TaskService.search(TaskService.taskList.get(0).getId()).getId()));
		assertTrue(TaskService.taskList.get(0).getName().equals(GOOD_NAME));
		assertTrue(TaskService.taskList.get(0).getDescription().equals(GOOD_DESCRIPTION));
		
		assertTrue(TaskService.taskList.get(1).getId().equals(TaskService.search(TaskService.taskList.get(1).getId()).getId()));
		assertTrue(TaskService.taskList.get(1).getName().equals(NAME));
		assertTrue(TaskService.taskList.get(1).getDescription().equals(DESCRIPTION));
	}
	
	@DisplayName("Bad Add Task")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			TaskService.addTask(BAD_NAME, BAD_DESCRIPTION);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			TaskService.addTask(GOOD_NAME, BAD_DESCRIPTION);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			TaskService.addTask(BAD_NAME, GOOD_DESCRIPTION);
		});
	}
	
	@DisplayName("Good Search")
	@Test
	void testThree() {
		assertEquals(TaskService.taskList.get(0).getId(), TaskService.search(TaskService.taskList.get(0).getId()).getId());
		assertEquals(TaskService.taskList.get(0).getName(), TaskService.search(TaskService.taskList.get(0).getId()).getName());
		assertEquals(TaskService.taskList.get(0).getDescription(), TaskService.search(TaskService.taskList.get(0).getId()).getDescription());
		
		assertEquals(TaskService.taskList.get(1).getId(), TaskService.search(TaskService.taskList.get(1).getId()).getId());
		assertEquals(TaskService.taskList.get(1).getName(), TaskService.search(TaskService.taskList.get(1).getId()).getName());
		assertEquals(TaskService.taskList.get(1).getDescription(), TaskService.search(TaskService.taskList.get(1).getId()).getDescription());		
	}
	
	@DisplayName("Bad Search")
	@Test
	void testFour() {
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getId().equals(BAD_ID));
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getName().equals(BAD_NAME));
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getDescription().equals(BAD_DESCRIPTION));
		
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getId().equals(BAD_ID));
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getName().equals(BAD_NAME));
		assertFalse(TaskService.search(TaskService.taskList.get(0).getId()).getDescription().equals(BAD_DESCRIPTION));		
	}
	
	@DisplayName("Remove")
	@Test
	void testFive() {
		UNIQUE_ID = TaskService.taskList.get(0).getId();
		TaskService.remove(TaskService.taskList.get(0).getId());
				
		assertTrue(TaskService.search(TaskService.taskList.get(0).getId()).getId().equals(TaskService.search(TaskService.taskList.get(0).getId()).getId()));
		assertTrue(TaskService.search(TaskService.taskList.get(0).getId()).getName().equals(NAME));
		assertTrue(TaskService.search(TaskService.taskList.get(0).getId()).getDescription().equals(DESCRIPTION));
		
		assertNull(TaskService.search(UNIQUE_ID));
	}
	
	@DisplayName("Update Info")
	@Test
	void testSix() {
		TaskService.updateName(TaskService.taskList.get(0).getId(), "z");
		TaskService.updateDescription(TaskService.taskList.get(0).getId(), "y");
		
		assertTrue(TaskService.taskList.get(0).getId().equals(TaskService.search(TaskService.taskList.get(0).getId()).getId()));
		assertTrue(TaskService.taskList.get(0).getName().equals("z"));
		assertTrue(TaskService.taskList.get(0).getDescription().equals("y"));
		
		TaskService.updateName(TaskService.taskList.get(1).getId(), "x");
		TaskService.updateDescription(TaskService.taskList.get(1).getId(), "w");
		
		assertTrue(TaskService.taskList.get(1).getId().equals(TaskService.search(TaskService.taskList.get(1).getId()).getId()));
		assertTrue(TaskService.taskList.get(1).getName().equals("x"));
		assertTrue(TaskService.taskList.get(1).getDescription().equals("w"));
	}
	
	@DisplayName("Unique ID")
	@Test
	void testSeven() {
		for (int i = 0; i < ID_COMPARISONS; i++) {
			assertFalse(TaskService.createId().equals(TaskService.taskList.get(0).getId()));
			assertFalse(TaskService.createId().equals(TaskService.taskList.get(1).getId()));
		}		
	}
}