package com.CS320.project1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TaskTest {
	protected String GOOD_ID, GOOD_NAME, GOOD_DESCRIPTION;
	protected String NULL_ID, NULL_NAME, NULL_DESCRIPTION;
	protected String LONG_ID, LONG_NAME, LONG_DESCRIPTION;
	protected Task GOOD_TASK, BAD_TASK, NULL_TASK, EMPTY_TASK;
	
	@BeforeAll
	void setup() {
		GOOD_ID = "a123abc!@#";
		GOOD_NAME = "John Brungard";
		GOOD_DESCRIPTION = "Automatically assigns weekly tasks for you.";
		
		NULL_ID = NULL_NAME = NULL_DESCRIPTION = null;
		
		LONG_ID = "a123abc!@#a123abc!@#";
		LONG_NAME = "JohnJohnJohnBrungardBrungard";
		LONG_DESCRIPTION = "The task object shall have a required description String field that "
				+ "cannot be longer than 50 characters.";
		
		GOOD_TASK = new Task(GOOD_ID, GOOD_NAME, GOOD_DESCRIPTION);
	}
	
	@DisplayName("Good Test")
	@Test
	void testOne() {	
		assertTrue(GOOD_TASK.getId().equals(GOOD_ID));
		assertTrue(GOOD_TASK.getName().equals(GOOD_NAME));
		assertTrue(GOOD_TASK.getDescription().equals(GOOD_DESCRIPTION));
	}
	
	@DisplayName("Null Test")
	@Test
	void testTwo() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task NULL_TASK = new Task(NULL_ID, GOOD_NAME, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task NULL_TASK = new Task(GOOD_ID, NULL_NAME, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task NULL_TASK = new Task(GOOD_ID, GOOD_NAME, NULL_DESCRIPTION);						
		});
	}
	
	@DisplayName("Empty Test")
	@Test
	void testThree() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task EMPTY_TASK = new Task("", GOOD_NAME, GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task EMPTY_TASK = new Task(GOOD_ID, "", GOOD_DESCRIPTION);						
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task EMPTY_TASK = new Task(GOOD_ID, GOOD_NAME, "");						
		});
	}
	
	@DisplayName("Bad Test")
	@Test
	void testFour() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_TASK.setName(LONG_NAME);			
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			GOOD_TASK.setDescription(LONG_DESCRIPTION);			
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			Task BAD_TASK  = new Task(LONG_ID, LONG_NAME, LONG_DESCRIPTION);		
		});		
	}
}
